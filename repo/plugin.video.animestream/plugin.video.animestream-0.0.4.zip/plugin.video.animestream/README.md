plugin.video.animestream
========================

anime streaming for XBMC